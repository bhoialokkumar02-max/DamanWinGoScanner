# Daman Win Go 1-Minute Scanner — Android source project

## Included
- Native Kotlin Android app with a dark scanner dashboard
- Android MediaProjection screen-capture permission flow
- On-device ML Kit text recognition (OCR)
- Basic period/result extraction heuristic
- Big/Small classification (5–9 Big; 0–4 Small)
- Colour classification rules in one editable parser
- Local SQLite history with duplicate-period protection

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `DamanWinGoScanner` folder.
4. Allow Gradle sync to complete.
5. Connect an Android device or create an emulator (screen capture is best tested on a real device).
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show the generated APK location.

## First run
1. Install and open the app.
2. Tap **START SCANNER** and approve Android's screen-capture prompt.
3. Open the Daman Win Go page on screen. Android may show a capture indicator while scanning.
4. Return to the scanner to review detected records; use **STOP SCANNER** to end capture.

## Important limitations / customization required
- This is a starter source project, not a prebuilt APK.
- OCR parsing is intentionally generic. Daman page layouts vary; the regex in `OcrParser.kt` currently selects a long numeric token as the period and the last isolated digit as the result. Validate and tune it against screenshots of the exact page before relying on saved records.
- Colour mapping in `OcrParser.kt` is a configurable placeholder rule set. Verify the platform's official result-to-colour mapping before use.
- OCR currently examines the captured screen and can misread unrelated digits (clock, balances, navigation, ads). A robust production version should crop the known result/period region, validate period progression and result layout, and expose a manual correction screen.
- Android may restrict or stop screen capture when protected content is displayed. Capture requires explicit user consent and remains visible to Android.
- This app does not log in, interact with the game, place bets, or predict future outcomes. Historical frequencies and sample accuracy must not be represented as guaranteed predictive accuracy.
- The project is provided as source; no signing key or APK is included.
