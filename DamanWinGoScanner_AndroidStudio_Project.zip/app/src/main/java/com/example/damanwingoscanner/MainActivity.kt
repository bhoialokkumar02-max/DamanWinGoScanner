package com.example.damanwingoscanner

import android.app.Activity
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val captureRequest = 1001
    private lateinit var status: TextView
    private lateinit var period: TextView
    private lateinit var result: TextView
    private lateinit var history: TextView
    private lateinit var store: ResultStore
    private var scanning = false

    private val resultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val p = intent?.getStringExtra("period") ?: return
            val n = intent.getIntExtra("number", -1)
            period.text = p
            result.text = "$n   ${intent.getStringExtra("size")}   ${intent.getStringExtra("colour")}"
            refreshHistory()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ResultStore(this)
        buildDashboard()
        ContextCompat.registerReceiver(this, resultReceiver,
            IntentFilter(ScreenCaptureService.ACTION_RESULT), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 20)
            setBackgroundColor(0xFF070817.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFF4F0FF.toInt()): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(4, 10, 4, 10) }
        root.addView(label("👑  DAMAN WIN GO", 25f, 0xFFFFD21F.toInt()))
        root.addView(label("1-MINUTE AUTOMATIC SCANNER", 17f, 0xFFB99CFF.toInt()))
        status = label("●  Scanner stopped", 18f, 0xFFFF5555.toInt()); root.addView(status)
        val start = Button(this).apply { text = "START SCANNER"; setOnClickListener { requestCapture() } }
        root.addView(start)
        val stop = Button(this).apply { text = "STOP SCANNER"; setOnClickListener { stopScanner() } }
        root.addView(stop)
        root.addView(label("LATEST DETECTED PERIOD", 14f, 0xFFB99CFF.toInt()))
        period = label("Waiting for screen capture…", 20f, 0xFFFFD21F.toInt()); root.addView(period)
        root.addView(label("LATEST RESULT", 14f, 0xFFB99CFF.toInt()))
        result = label("—", 26f, 0xFF35E66B.toInt()); root.addView(result)
        root.addView(label("TRACKING", 18f))
        root.addView(label("Big: 5–9     Small: 0–4\nColours: Red • Green • Violet", 17f))
        root.addView(label("HISTORICAL RECORDS", 18f))
        history = label("", 13f); root.addView(ScrollView(this).apply { addView(history) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label("Note: OCR results must be checked against the game display. No outcome prediction is guaranteed.",
            12f, 0xFFB7B2C8.toInt()))
        setContentView(root)
        refreshHistory()
    }

    private fun requestCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode); putExtra("data", data)
            }
            ContextCompat.startForegroundService(this, service)
            scanning = true
            status.text = "●  Screen scanning active"
            status.setTextColor(0xFF35E66B.toInt())
        }
    }

    private fun stopScanner() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        scanning = false
        status.text = "●  Scanner stopped"
        status.setTextColor(0xFFFF5555.toInt())
    }

    private fun refreshHistory() {
        history.text = store.recent(25).joinToString("\n") {
            "${it.period}   ${it.number}   ${it.size}   ${it.colour}"
        }.ifBlank { "No scanned records yet." }
    }

    override fun onDestroy() {
        try { unregisterReceiver(resultReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
