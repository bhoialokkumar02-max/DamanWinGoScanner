package com.example.damanwingoscanner

data class ParsedResult(val period: String?, val number: Int?)

object OcrParser {
    // Generic heuristic: adapt these patterns to the exact visible Daman page layout.
    private val periodPattern = Regex("(?<!\\d)(\\d{10,20})(?!\\d)")
    fun parse(text: String): ParsedResult {
        val period = periodPattern.findAll(text).map { it.groupValues[1] }
            .maxByOrNull { it.length }
        val number = Regex("(?<!\\d)([0-9])(?!\\d)").findAll(text)
            .map { it.groupValues[1].toInt() }.lastOrNull()
        return ParsedResult(period, number)
    }
    fun size(n: Int) = if (n >= 5) "Big" else "Small"
    fun colour(n: Int): String = when (n) {
        0, 5 -> "Violet"
        1, 3, 7, 9 -> "Green"
        else -> "Red"
    }
}
