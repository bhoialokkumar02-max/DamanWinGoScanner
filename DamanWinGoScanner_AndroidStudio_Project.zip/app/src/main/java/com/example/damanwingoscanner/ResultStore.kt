package com.example.damanwingoscanner

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ScanRecord(
    val period: String, val number: Int, val size: String, val colour: String, val capturedAt: Long
)

class ResultStore(context: Context) : SQLiteOpenHelper(context, "scan_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE records(
            period TEXT PRIMARY KEY, number INTEGER NOT NULL, size TEXT NOT NULL,
            colour TEXT NOT NULL, captured_at INTEGER NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun insertIfNew(record: ScanRecord): Boolean {
        val values = android.content.ContentValues().apply {
            put("period", record.period); put("number", record.number)
            put("size", record.size); put("colour", record.colour)
            put("captured_at", record.capturedAt)
        }
        return writableDatabase.insertWithOnConflict("records", null, values,
            SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }
    fun recent(limit: Int = 30): List<ScanRecord> {
        val out = mutableListOf<ScanRecord>()
        readableDatabase.rawQuery(
            "SELECT period,number,size,colour,captured_at FROM records ORDER BY captured_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out += ScanRecord(c.getString(0), c.getInt(1),
                c.getString(2), c.getString(3), c.getLong(4))
        }
        return out
    }
}
