package com.example.damanwingoscanner

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var lastProcessed = 0L
    private val store by lazy { ResultStore(this) }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        createNotificationChannel()
        startForeground(7, NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Daman Win Go Scanner")
            .setContentText("Screen scanning is active")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true).build())

        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }

        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            startCapture()
        } catch (_: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        thread = HandlerThread("screen-ocr").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastProcessed < 2500) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastProcessed = now
            processImage(image)
        }, handler)
        display = projection?.createVirtualDisplay("DamanScanner", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
    }

    private fun processImage(image: Image) {
        val bitmap = image.toBitmapSafe()
        image.close()
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { visionText ->
                val parsed = OcrParser.parse(visionText.text)
                val n = parsed.number
                val p = parsed.period
                if (n != null && p != null) {
                    val rec = ScanRecord(p, n, OcrParser.size(n), OcrParser.colour(n), System.currentTimeMillis())
                    if (store.insertIfNew(rec)) {
                        sendBroadcast(Intent(ACTION_RESULT).setPackage(packageName).apply {
                            putExtra("period", rec.period); putExtra("number", rec.number)
                            putExtra("size", rec.size); putExtra("colour", rec.colour)
                        })
                    }
                }
            }
    }

    private fun Image.toBitmapSafe(): android.graphics.Bitmap {
        val plane = planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val padded = android.graphics.Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        return android.graphics.Bitmap.createBitmap(padded, 0, 0, width, height)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Screen scanner", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop()
        thread?.quitSafely(); recognizer.close()
        super.onDestroy()
    }
    companion object {
        const val ACTION_RESULT = "com.example.damanwingoscanner.RESULT"
        const val ACTION_STOP = "com.example.damanwingoscanner.STOP"
        private const val CHANNEL = "scanner_channel"
    }
}
