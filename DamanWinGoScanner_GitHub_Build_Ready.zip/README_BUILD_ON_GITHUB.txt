GITHUB MOBILE BUILD SETUP

This project ZIP includes .github/workflows/android-apk.yml.
Upload the contents of this ZIP to the ROOT of your GitHub repository, keeping the .github folder.
Then open the repository's Actions tab, choose "Build Android APK", tap "Run workflow", and confirm.
When the run finishes successfully, open the run and download the artifact named "DamanWinGoScanner-debug-apk".

Note: This is a starter project and the first build may reveal source/dependency issues that need fixing. The APK is not guaranteed until a successful build completes. The scanner is for screen-reading/statistics only, not guaranteed predictions or automatic betting.
